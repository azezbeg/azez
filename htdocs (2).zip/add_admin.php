<?php
require 'db.php';
require 'includes/header.php';






// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = htmlspecialchars($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $type = htmlspecialchars($_POST['type']);
    $image = $_FILES['image'];

    // Validate input
    if (empty($username) || empty($password) || empty($confirm_password) || empty($type)) {
        $error = "All fields are required.";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        // Handle image upload
        if ($image['error'] === 0) {
            $image_path = 'uploads/admins/' . basename($image['name']);
            if (!move_uploaded_file($image['tmp_name'], $image_path)) {
                $error = "Failed to upload image.";
            }
        } else {
            $image_path = null; // Optional: default image path
        }

        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert admin into the database
        $stmt = $pdo->prepare("INSERT INTO admins (name, password, type, image) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$username, $hashed_password, $type, $image_path])) {
            $success = "Admin added successfully.";
        } else {
            $error = "Failed to add admin.";
        }
    }
}
?>

<body>
    <div class="container">
        <div class="form-container">
            <!-- Back Button -->
            <a href="manage_admins.php" class="btn btn-secondary btn-back">← Back to Manage Admins</a>

            <!-- Page Title -->
            <h1 class="form-title">Add Admin</h1>

            <!-- Error/Success Message -->
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php elseif (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

            <!-- Add Admin Form -->
            <form method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="mb-3">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" id="password" name="password" required>
                </div>
                <div class="mb-3">
                    <label for="confirm_password" class="form-label">Confirm Password</label>
                    <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
                </div>
                <div class="mb-3">
                    <label for="type" class="form-label">Type</label>
                    <select class="form-select" id="type" name="type" required>
                        <option value="super_manager">Super Manager</option>
                        <option value="admin">Admin</option>
                        <option value="editor">Editor</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label for="image" class="form-label">Upload Image</label>
                    <input type="file" class="form-control" id="image" name="image" accept="image/*">
                </div>
                <button type="submit" class="btn btn-primary">Add Admin</button>
            </form>
        </div>
    </div>

   
<?php
require 'includes/footer.php';?>