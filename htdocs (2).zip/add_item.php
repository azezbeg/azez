<?php
require 'db.php';
require 'includes/header.php';



// Fetch categories for the dropdown
$sql = "SELECT id, name FROM categories";
$stmt = $pdo->query($sql);
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $uyghurName = $_POST['uyghur_name'];
    $englishName = $_POST['english_name'];
    $arabicName = $_POST['arabic_name'];
    $categoryId = $_POST['category_id'];
    $Notes = $_POST['Notes'];
    $image = $_FILES['image'];
     $image = $_FILES['image'];

    // Handle image upload
    $imagePath = null;
    if ($image['error'] === UPLOAD_ERR_OK) {
        $imageDir = "";
        $imagePath = $imageDir . basename($image['name']);
        move_uploaded_file($image['tmp_name'], $imagePath);
    }

    // Insert new item into the database
    $sql = "INSERT INTO items (uyghur_name, english_name, arabic_name, category_id, image, Notes) 
            VALUES (:uyghur_name, :english_name, :arabic_name, :category_id, :image, :Notes)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':uyghur_name', $uyghurName);
    $stmt->bindParam(':english_name', $englishName);
    $stmt->bindParam(':arabic_name', $arabicName);
    $stmt->bindParam(':category_id', $categoryId);
    $stmt->bindParam(':image', $imagePath);
    $stmt->bindParam(':Notes', $Notes);
    $stmt->execute();

    header("Location: manage_items.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Item</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f4f4f9;
        }

        .navbar {
            background: linear-gradient(to right, #2575fc, #6a11cb);
            color: white;
        }

        .navbar-brand {
            font-weight: bold;
            color: #fff !important;
        }

        .form-container {
            max-width: 800px;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .form-container h3 {
            margin-bottom: 20px;
        }

        .image-preview {
            display: block;
            margin: 10px 0;
            width: 150px;
            height: 150px;
            object-fit: cover;
            border-radius: 10px;
            border: 1px solid #ddd;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
  

    <!-- Add New Item Form -->
    <div class="form-container">
        <h3>Add New Item</h3>
        <form action="add_item.php" method="post" enctype="multipart/form-data">
            <div class="form-group mb-3">
                <label for="uyghur_name">Uyghur Name</label>
                <input type="text" id="uyghur_name" name="uyghur_name" class="form-control" required>
            </div>
            <div class="form-group mb-3">
                <label for="english_name">English Name</label>
                <input type="text" id="english_name" name="english_name" class="form-control" required>
            </div>
            <div class="form-group mb-3">
                <label for="arabic_name">Arabic Name</label>
                <input type="text" id="arabic_name" name="arabic_name" class="form-control" required>
            </div>
            <div class="form-group mb-3">
                <label for="category_id">Category</label>
                <select id="category_id" name="category_id" class="form-select" required>
                    <option value="" disabled selected>Select Category</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['id']; ?>"><?php echo htmlspecialchars($category['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group mb-3">
                <label for="image">Item Image</label>
                <input type="file" id="image" name="image" class="form-control" accept="image/*" required onchange="previewImage(event)">
                <img id="image-preview" class="image-preview" src="#" alt="Image Preview" style="display: none;">
            </div>
            <div class="form-group mb-3">
                <label for="Notes"> Uyghur Notes</label>
                <input type="text" id="Notes" name="Notes" class="form-control" placeholder="Enter Uyghur Notes" required>
            </div>
            <div class="d-flex justify-content-between">
                <a href="manage_items.php" class="btn btn-secondary">Cancel</a>
                <button type="submit" class="btn btn-primary">Add Item</button>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Function to preview image
        function previewImage(event) {
            const preview = document.getElementById('image-preview');
            const file = event.target.files[0];

            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                };
                reader.readAsDataURL(file);
            } else {
                preview.style.display = 'none';
            }
        }
    </script>
</body>
</html>

<?php
require 'includes/footer.php';?>