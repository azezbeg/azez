<?php
// MySQLغا ئۇلىنىش ئۇچۇرى
$servername = "localhost";  // ياكى شىركەتنىڭ مەشغۇلات ئورنىغا قاراپ
$username = "root";         // ئىشلىتىدىغان يىگىتنىڭ ئىسمى
$password = "";             // پارول
$dbname = "admin_panel";  // پىدائى ھالىتىنى تاپشۇرۇش

// ئۇلىنىشنى تەكشۈرۈش
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("ئۇلىنىش خەتىلۈك: " . $conn->connect_error);
}

// رەسىمنى قاچىلاش ۋە تېكىتلەرنى قوبۇل قىلىش
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $uyghur_name = $_POST['uyghur_name'];
    $english_name = $_POST['english_name'];
    $arabic_name = $_POST['arabic_name'];
    $category_id = $_POST['category_id'];
    $notes = $_POST['notes'];
    $created_at = date('Y-m-d H:i:s');  // يېڭى ۋاقىتنى تەڭشەش
    
    // رەسىمنى قوبۇل قىلىش
    $image = $_FILES['image']['name']; // رەسىم نامى
    $target_dir = "uploads/"; // رەسىمنى ساقلاش يولى
    $target_file = $target_dir . basename($image);

    // رەسىمنى قاچىلاش
    if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
        echo "رەسىم مۇۋەپپەقىيەتلىك قاچىلاندى.";
    } else {
        echo "رەسىم قاچىلانمىدى.";
    }

    // SQL سۆزىنى ياساش
    $sql = "INSERT INTO items (uyghur_name, english_name, arabic_name, category_id, image, created_at, notes) 
            VALUES ('$uyghur_name', '$english_name', '$arabic_name', '$category_id', '$image', '$created_at', '$notes')";
    
    // مەزمۇننى PHPMyAdminغا يوللاش
    if ($conn->query($sql) === TRUE) {
        echo "مەزمۇن مۇۋەپپەقىيەتلىك يوللاندى!";
    } else {
        echo "خەتىلۈك: " . $conn->error;
    }
}
$conn->close();
?>
