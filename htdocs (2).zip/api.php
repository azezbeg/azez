<?php
require 'db.php';

// Set the response header to JSON
header('Content-Type: application/json');

// Function to respond with JSON and exit
function respond($status, $message, $data = []) {
    echo json_encode(['status' => $status, 'message' => $message, 'data' => $data]);
    exit;
}

// Check if the API key is provided
if (!isset($_GET['api_key'])) {
    respond('error', 'API key is required.');
}

$api_key = htmlspecialchars($_GET['api_key']);

// Validate the API key
$stmt = $pdo->prepare("SELECT * FROM admin_api_keys WHERE api_key = ?");
$stmt->execute([$api_key]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$admin) {
    respond('error', 'Invalid API key.');
}

// Handle different API requests
$action = $_GET['action'] ?? '';

switch ($action) {
    case 'get_settings':
        // Fetch website settings
        $stmt = $pdo->query("SELECT website_name, welcome_name, logo FROM settings LIMIT 1");
        $settings = $stmt->fetch(PDO::FETCH_ASSOC);
        respond('success', 'Settings retrieved successfully.', $settings);
        break;

    case 'get_categories':
        // Fetch all categories
        $stmt = $pdo->query("SELECT * FROM categories");
        $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
        respond('success', 'Categories retrieved successfully.', $categories);
        break;

    case 'get_users':
        // Fetch all users
        $stmt = $pdo->query("SELECT id,username, type_user, email, user_image,Validity, reg_date FROM users");
        $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
        respond('success', 'Users retrieved successfully.', $users);
        break;

    case 'get_admins':
        // Fetch all admins
        $stmt = $pdo->query("SELECT id, username, password FROM admins");
        $admins = $stmt->fetchAll(PDO::FETCH_ASSOC);
        respond('success', 'Admins retrieved successfully.', $admins);
        break;

    case 'get_items':
        // Fetch all items, ordered by createdAt (newest first)
        $stmt = $pdo->query("SELECT * FROM items ORDER BY created_at DESC");
        $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
        respond('success', 'Items retrieved successfully.', $items);
        break;

    case 'edit_profile':
        // Edit user profile
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $user_id = $_POST['user_id'] ?? null; // Make sure the user_id is provided
            $username = $_POST['username'] ?? null;
            $email = $_POST['email'] ?? null;
            $user_image = $_FILES['user_image'] ?? null; // Handle the uploaded image

            if (!$user_id || !$username || !$email) {
                respond('error', 'Missing required fields.');
            }

            // Handle image upload if provided
            if ($user_image) {
                $target_dir = "uploads/";
                $target_file = $target_dir . basename($user_image["name"]);
                if (move_uploaded_file($user_image["tmp_name"], $target_file)) {
                    $user_image_path = $target_file;
                } else {
                    $user_image_path = null; // Handle image upload failure
                }
            }

            // Update user information in the database
            $update_query = "UPDATE users SET username = ?, email = ?";
            $params = [$username, $email];

            if (isset($user_image_path)) {
                $update_query .= ", user_image = ?";
                $params[] = $user_image_path;
            }

            $update_query .= " WHERE id = ?";
            $params[] = $user_id;

            $stmt = $pdo->prepare($update_query);
            $stmt->execute($params);

            respond('success', 'Profile updated successfully.');
        } else {
            respond('error', 'Invalid request method. POST required.');
        }
        break;

    default:
        respond('error', 'Invalid action.');
}
?>
