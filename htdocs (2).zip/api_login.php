<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "admin_panel";

// MySQL قوشۇلمىسىنى بۇرۇنقى خاتالىقلىرىدىن ساقلانغان ھەلدە قۇرۇش
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
$conn = new mysqli($servername, $username, $password, $dbname);
$conn->set_charset("utf8mb4"); // ئۇيغۇرچە ۋە باشقا ھەرپلەرنى قوللاش

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $input_username = trim($_POST['username']);
    $input_password = $_POST['password'];

    if (empty($input_username) || empty($input_password)) {
        echo json_encode(["status" => "error", "message" => "Username and password are required!"]);
        exit();
    }

    $stmt = $conn->prepare("SELECT password FROM users WHERE username = ?");
    $stmt->bind_param("s", $input_username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($hashed_password);
        $stmt->fetch();

        if (password_verify($input_password, $hashed_password)) {
            echo json_encode(["status" => "success"]);
        } else {
            echo json_encode(["status" => "error", "message" => "Invalid username or password"]);
        }
    } else {
        echo json_encode(["status" => "error", "message" => "User not found"]);
    }

    $stmt->close();
}

$conn->close();
?>
