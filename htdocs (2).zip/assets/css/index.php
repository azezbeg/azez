<!DOCTYPE html>
<html>
<head>
    <title>Dashboard - Home</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <?php include('sidebar.php'); ?>
    <div class="content">
        <h1>Welcome to the Dashboard</h1>
        <p>This is the main content area of the dashboard.</p>
    </div>
</body>
</html>
