<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>
<div class="sidebar" id="sidebar">
    <h2 style="text-align: center;">Dashboard</h2>
    <a href="index.php" class="<?= $current_page == 'index.php' ? 'active' : '' ?>">Home</a>
    <a href="users.php" class="<?= $current_page == 'users.php' ? 'active' : '' ?>">Users</a>
    <a href="reports.php" class="<?= $current_page == 'reports.php' ? 'active' : '' ?>">Reports</a>
    <a href="settings.php" class="<?= $current_page == 'settings.php' ? 'active' : '' ?>">Settings</a>
    <a href="logout.php" class="<?= $current_page == 'logout.php' ? 'active' : '' ?>">Logout</a>
</div>
