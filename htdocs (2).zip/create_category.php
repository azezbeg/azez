<?php
require 'db.php';
require 'includes/header.php';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $image = $_FILES['image'];

    // Handle image upload
    if ($image['error'] === UPLOAD_ERR_OK) {
        $targetDir = "uploads/";
        $targetFile = $targetDir . basename($image['name']);
        move_uploaded_file($image['tmp_name'], $targetFile);

        $sql = "INSERT INTO categories (name, image) VALUES (:name, :image)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':image', $targetFile);
        $stmt->execute();

        header("Location: manage_categories.php");
        exit;
    } else {
        $error = "Error uploading image. Please try again.";
    }
}
?>



    <!-- Create Category Form -->
    <div class="form-container">
        <h3>Create Category</h3>
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger"><?php echo $error; ?></div>
        <?php endif; ?>
        <form action="create_category.php" method="post" enctype="multipart/form-data">
            <div class="form-group mb-3">
                <label for="name">Category Name</label>
                <input type="text" id="name" name="name" class="form-control" required>
            </div>
            <div class="form-group mb-3">
                <label for="image">Category Image</label>
                <input type="file" id="image" name="image" class="form-control" accept="image/*" required onchange="previewImage(event)">
                <img id="image-preview" class="image-preview" src="#" alt="Image Preview" style="display: none;">
            </div>
            <div class="d-flex justify-content-between">
                <a href="manage_categories.php" class="btn btn-secondary">Cancel</a>
                <button type="submit" class="btn btn-primary">Create Category</button>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Function to preview image
        function previewImage(event) {
            const preview = document.getElementById('image-preview');
            const file = event.target.files[0];

            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                };
                reader.readAsDataURL(file);
            } else {
                preview.style.display = 'none';
            }
        }
    </script>
</body>
</html>


<?php
require 'includes/footer.php';?>