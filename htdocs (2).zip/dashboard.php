<?php
require 'db.php';
require 'includes/header.php';



$items_count = $pdo->query("SELECT COUNT(*) FROM items")->fetchColumn();
$categories_count = $pdo->query("SELECT COUNT(*) FROM categories")->fetchColumn();
$admins_count = $pdo->query("SELECT COUNT(*) FROM admins")->fetchColumn();
?>


<!-- Main Content -->
<div class="main-content" id="main-content">
    <div class="container mt-5">
        <h2 class="text-center mb-4">Welcome, <?php echo $_SESSION['username']; ?>!</h2>
        <div class="row g-4">
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                    <a href="https://www.w3schools.com">

                        <div class="icon icon-users">
                            <i class="fas fa-users"></i>
                            </a>
                        </div>
                        <h5 class="card-title">Users</h5>
                        <p class="card-text"><?php echo $items_count; ?></p>
                        
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <div class="icon icon-revenue">
                            <i class="fas fa-chart-line"></i>
                        </div>
                        <h5 class="card-title">category</h5>
                        <p class="card-text"><?php echo $categories_count; ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <div class="icon icon-orders">
                            <i class="fas fa-box"></i>
                        </div>
                        <h5 class="card-title">admins</h5>
                        <p class="card-text"><?php echo $admins_count; ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-3">
                <div class="card">
                    <div class="card-body">
                        <div class="icon icon-feedback">
                            <i class="fas fa-comments"></i>
                        </div>
                        <h5 class="card-title">Feedback</h5>
                        <p class="card-text">12 New Feedbacks</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>



<?php
require 'includes/footer.php';?>