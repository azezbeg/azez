<?php
session_start();
if (!isset($_SESSION['logged_in'])) {
    header('Location: login.php');
    exit;
}

require 'db.php';

// Check if ID is provided
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    
    // Confirm if admin exists
    $stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
    $stmt->execute([$id]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        $_SESSION['error'] = "Admin not found.";
        header('Location: manage_admins.php');
        exit;
    }

    // Delete the admin
    $stmt = $pdo->prepare("DELETE FROM admins WHERE id = ?");
    $stmt->execute([$id]);

    // Redirect with a success message
    $_SESSION['success'] = "Admin successfully deleted.";
    header('Location: manage_admins.php');
    exit;
} else {
    // Redirect if no ID provided
    $_SESSION['error'] = "No admin ID provided.";
    header('Location: manage_admins.php');
    exit;
}
?>
