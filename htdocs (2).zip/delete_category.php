<?php
session_start();
if (!isset($_SESSION['logged_in'])) {
    header('Location: login.php');
    exit;
}

require 'db.php';

// Check if the category ID is provided
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $categoryId = intval($_GET['id']);

    // Check if the category exists
    $stmt = $pdo->prepare("SELECT * FROM categories WHERE id = ?");
    $stmt->execute([$categoryId]);
    $category = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($category) {
        // Delete the category
        $deleteStmt = $pdo->prepare("DELETE FROM categories WHERE id = ?");
        if ($deleteStmt->execute([$categoryId])) {
            $_SESSION['message'] = "Category deleted successfully.";
            $_SESSION['message_type'] = "success";
        } else {
            $_SESSION['message'] = "Failed to delete the category. Please try again.";
            $_SESSION['message_type'] = "danger";
        }
    } else {
        $_SESSION['message'] = "Category not found.";
        $_SESSION['message_type'] = "warning";
    }
} else {
    $_SESSION['message'] = "Invalid category ID.";
    $_SESSION['message_type'] = "warning";
}

// Redirect to the Manage Categories page
header('Location: manage_categories.php');
exit;
?>
