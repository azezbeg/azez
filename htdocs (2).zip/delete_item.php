<?php
session_start();
if (!isset($_SESSION['logged_in'])) {
    header('Location: login.php');
    exit;
}

require 'db.php';

$itemId = $_GET['id'] ?? null;

if (!$itemId) {
    header('Location: manage_items.php');
    exit;
}

$sql = "DELETE FROM items WHERE id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$itemId]);

header('Location: manage_items.php?delete_success=1');
exit;
