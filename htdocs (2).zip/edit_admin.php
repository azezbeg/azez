<?php
require 'db.php';
require 'includes/header.php';



// Fetch admin data if ID is provided
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $stmt = $pdo->prepare("SELECT * FROM admins WHERE id = ?");
    $stmt->execute([$id]);
    $admin = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$admin) {
        die("Admin not found.");
    }
} else {
    die("No ID provided.");
}

// Update admin details when form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $type = htmlspecialchars($_POST['type']);

    // Validate input
    if (empty($name) || empty($email) || empty($type)) {
        $error = "All fields are required.";
    } else {
        // Update the admin in the database
        $stmt = $pdo->prepare("UPDATE admins SET name = ?, email = ?, type = ? WHERE id = ?");
        $stmt->execute([$name, $email, $type, $id]);
        $success = "Admin details updated successfully.";
        // Refresh the page with updated data
        header("Location: manage_admins.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Admin</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .main-container {
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            margin: 50px auto;
        }
        .page-title {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 20px;
        }
        .btn-back {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="main-container">
            <!-- Back Button -->
            <a href="manage_admins.php" class="btn btn-secondary btn-back">← Back to Manage Admins</a>

            <!-- Page Title -->
            <h1 class="page-title">Edit Admin</h1>

            <!-- Error/Success Message -->
            <?php if (isset($error)): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php elseif (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

            <!-- Edit Admin Form -->
            <form method="POST">
                <div class="mb-3">
                    <label for="name" class="form-label">Name</label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo htmlspecialchars($admin['username']); ?>" required>
                </div>
                
                <div class="mb-3">
                    <label for="type" class="form-label">Type</label>
                    <select class="form-select" id="type" name="type" required>
                        <option value="super_manager" <?php echo $admin['role'] === 'super_manager' ? 'selected' : ''; ?>>Super Manager</option>
                        <option value="admin" <?php echo $admin['role'] === 'admin' ? 'selected' : ''; ?>>Admin</option>
                        <option value="editor" <?php echo $admin['role'] === 'editor' ? 'selected' : ''; ?>>Editor</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Update Admin</button>
            </form>
        </div>
    </div>

    <!-- Bootstrap Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
require 'includes/footer.php';?>