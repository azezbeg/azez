<?php
require 'db.php';
require 'includes/header.php';



// Get item ID from the query string
$itemId = $_GET['id'] ?? null;

if (!$itemId) {
    header('Location: manage_items.php');
    exit;
}

// Fetch the item details
$sql = "SELECT * FROM items WHERE id = ?";
$stmt = $pdo->prepare($sql);
$stmt->execute([$itemId]);
$item = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$item) {
    header('Location: manage_items.php');
    exit;
}

// Fetch categories for the dropdown
$categoriesSql = "SELECT * FROM categories";
$categoriesStmt = $pdo->query($categoriesSql);
$categories = $categoriesStmt->fetchAll(PDO::FETCH_ASSOC);

// Update the item
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $englishName = $_POST['english_name'];
    $uyghurName = $_POST['uyghur_name'];
    $arabicName = $_POST['arabic_name'];
    $categoryId = $_POST['category_id'];
    $imageUrl = $_POST['image_url'];
    $voiceUrl = $_POST['voice_url'];

    $updateSql = "UPDATE items SET 
        english_name = ?, 
        uyghur_name = ?, 
        arabic_name = ?, 
        category_id = ?, 
        image_url = ?, 
        voice_url = ? 
        WHERE id = ?";
    $stmt = $pdo->prepare($updateSql);
    $stmt->execute([$englishName, $uyghurName, $arabicName, $categoryId, $imageUrl, $voiceUrl, $itemId]);

    header('Location: manage_items.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Item</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f4f4f9;
        }
        .navbar {
            background: linear-gradient(to right, #2575fc, #6a11cb);
            color: white;
        }
        .navbar-brand {
            font-weight: bold;
            color: #fff !important;
        }
        .form-container {
            max-width: 800px;
            margin: 50px auto;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .form-container h3 {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <!-- Navbar -->


    <!-- Edit Item Form -->
    <div class="form-container">
        <h3>Edit Item</h3>
        <form action="" method="post">
            <div class="form-group mb-3">
                <label for="english_name">English Name</label>
                <input type="text" id="english_name" name="english_name" class="form-control" value="<?php echo htmlspecialchars($item['english_name']); ?>" required>
            </div>
            <div class="form-group mb-3">
                <label for="uyghur_name">Uyghur Name</label>
                <input type="text" id="uyghur_name" name="uyghur_name" class="form-control" value="<?php echo htmlspecialchars($item['uyghur_name']); ?>" required>
            </div>
            <div class="form-group mb-3">
                <label for="arabic_name">Arabic Name</label>
                <input type="text" id="arabic_name" name="arabic_name" class="form-control" value="<?php echo htmlspecialchars($item['arabic_name']); ?>" required>
            </div>
            <div class="form-group mb-3">
                <label for="category_id">Category</label>
                <select id="category_id" name="category_id" class="form-select" required>
                    <option value="" disabled>Select Category</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?php echo $category['id']; ?>" <?php echo $item['category_id'] == $category['id'] ? 'selected' : ''; ?>>
                            <?php echo htmlspecialchars($category['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group mb-3">
                <label for="image_url">Image URL</label>
                <input type="url" id="image" name="image" class="form-control" value="<?php echo htmlspecialchars($item['image']); ?>" required  onchange="previewImage(event)">
                <img id="image-preview" class="image-preview" src="<?php echo htmlspecialchars($item['image']); ?>" alt="Image Preview" style="display: none;">
            </div>
            <div class="form-group mb-3">
                <label for="voice_url">Uyghur Voice URL</label>
                <input type="url" id="voice_url" name="voice_url" class="form-control" value="<?php echo htmlspecialchars($item['voice_url']); ?>
            </div>
            <div class="d-flex justify-content-between">
                <a href="manage_items.php" class="btn btn-secondary">Cancel</a>
                <button type="submit" class="btn btn-primary">Update Item</button>
            </div>
        </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
require 'includes/footer.php';?>