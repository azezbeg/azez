<?php
// MySQL ئالاقە تىزىملىكى
$servername = "localhost"; // سەرۋېردىكى ئەڭ ئاساسى خەتكۈچ
$username = "root"; // سانلىق مەلۇماتنىڭ ئىشلەتكۈچى ئادرىسى
$password = ""; // پارول
$dbname = "admin_panel"; // سانلىق مەلۇماتنىڭ ئاتى

// سانلىق مەلۇماتقا چۈشۈپ، ئالاقە قىلىش
$conn = new mysqli($servername, $username, $password, $dbname);

// ئالاقە خاتالىقىنى تەكشۈرۈش
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}




session_start(); // سىستىما داۋامىدا سېسىيە مەلۇماتىنى ساقلاش

// سۈرەت تۈرلىرىنى چەكلىش
$allowed_types = ['image/jpeg', 'image/png', 'image/jpg'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $id = $_SESSION['id']; // ئابونتنىڭ كۆدى

    // سۈرەت ئالىش
    if (isset($_FILES['user_image']) && $_FILES['user_image']['error'] == 0) {
        $file_name = $_FILES['user_image']['name'];
        $file_tmp = $_FILES['user_image']['tmp_name'];
        $file_size = $_FILES['user_image']['size'];
        $file_type = $_FILES['user_image']['type'];

        // سۈرەتنىڭ تۈرىنى تەكشۈرۈش
        if (in_array($file_type, $allowed_types)) {
            $target_dir = "uploads/";  // سۈرەتنىڭ ساقلانغان جايى
            $target_file = $target_dir . basename($file_name);
            
            // سۈرەتنى ساقلاش
            move_uploaded_file($file_tmp, $target_file);
        } else {
            echo "Only JPEG, PNG, and JPG files are allowed.";
            exit;
        }
    } else {
        // ئەگەر سۈرەت قىستۇرۇلمايدىغان بولسا، ئالدىنقى سۈرەتنى ساقلا
        $target_file = $_POST['current_image']; // ئەگەر سۈرەت ئۆزگەرتمىسىمۇ، ئالدىنقى سۈرەت ساقلىنىشى
    }

    // پارولنىڭ يېڭىلىنىشى
    if (!empty($password)) {
        // پارولنى قوغداش: ھەققىدىكى مۇناسىۋەتلىك پىچەتلەرنى چەكلەش
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
    } else {
        // ئەگەر پارول يىڭىلىنىشى ئارقىلىق ئەمەس بولسا، بويلاپ ئۆتۈش
        $password_hash = null;
    }

    // SQL كېلىشىم
    if ($password_hash != null) {
        $sql = "UPDATE users SET username = ?, password = ?, user_image = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $username, $password_hash, $target_file, $id);
    } else {
        $sql = "UPDATE users SET username = ?, user_image = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $username, $target_file, $id);
    }

    // يىڭىلاش
    if ($stmt->execute()) {
        echo "Profile updated successfully!";
    } else {
        echo "Error updating profile: " . $conn->error;
    }
    $stmt->close();
}

$conn->close();
?>
