<?php
require 'db.php';
session_start();
if (!isset($_SESSION['logged_in'])) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- FontAwesome Icons -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="assets/css/style.css" rel="stylesheet">
</head>
<body>

<!-- Top Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark">
    <div class="container-fluid">
        <span class="toggle-btn" id="toggle-btn">
            <i class="fas fa-bars"></i>
        </span>
        <a class="navbar-brand ms-5" href="dashboard.php">Admin Dashboard</a>
       
    </div>
</nav>

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
    <ul>
        <li><a href="dashboard.php"><i class="fas fa-home icon"></i> Home</a></li>
        <li><a href="add_user.php"><i class="fas fa-users icon"></i> Users</a></li>
        <li><a href="create_category.php"><i class="fas fa-box icon"></i> Create Category Page</a></li>
        <li><a href="manage_categories.php"><i class="fas fa-chart-line icon"></i> manage_categories</a></li>
        <li><a href="add_item.php"><i class="fas fa-chart-line icon"></i> add_new_item</a></li>
        <li><a href="manage_items.php"><i class="fas fa-chart-line icon"></i> manage_items</a></li>
        <li><a href="add_admin.php"><i class="fas fa-chart-line icon"></i> add_new_admin</a></li>
        <li><a href="manage_admins.php"><i class="fas fa-chart-line icon"></i> manage_admin</a></li>
        <li><a href="settings.php"><i class="fas fa-cogs icon"></i> Settings</a></li>

        <li><a href="logout.php"><i class="fas fa-sign-out-alt icon"></i> Logout</a></li>
    </ul>
</div>