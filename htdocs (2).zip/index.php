<?php
// Start session for login management
session_start();
if (!isset($_SESSION['logged_in'])) {
    header('Location: login.php');
    exit;
}
?>

<?php include 'templates/header.php'; ?>

<div class="container mt-4">
    <h1>Welcome to the Admin Panel</h1>
    <a href="dashboard.php" class="btn btn-primary">Go to Dashboard</a>
</div>

<?php include 'templates/footer.php'; ?>
