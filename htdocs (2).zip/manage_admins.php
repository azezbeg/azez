<?php
require 'db.php';
require 'includes/header.php';



// Fetch all admins from the database
$stmt = $pdo->query("SELECT * FROM admins ORDER BY created_at DESC");
$admins = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Admins</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
        }
        .admin-card {
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            overflow: hidden;
            margin-bottom: 20px;
            background: #fff;
        }
        .admin-card img {
            height: 150px;
            width: 100%;
            object-fit: cover;
        }
        .card-body {
            text-align: center;
        }
        .admin-name {
            font-size: 1.25rem;
            font-weight: bold;
        }
        .admin-type {
            font-size: 0.875rem;
            color: #6c757d;
        }
        .btn-edit {
            background-color: #007bff;
            color: #fff;
        }
        .btn-edit:hover {
            background-color: #0056b3;
        }
        .btn-delete {
            background-color: #dc3545;
            color: #fff;
        }
        .btn-delete:hover {
            background-color: #b02a37;
        }
        .action-buttons {
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="container mt-4">
        <h1 class="text-center mb-4">Manage Admins</h1>

        <!-- Success/Error Messages -->
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success"><?php echo $_SESSION['success']; unset($_SESSION['success']); ?></div>
        <?php endif; ?>
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger"><?php echo $_SESSION['error']; unset($_SESSION['error']); ?></div>
        <?php endif; ?>

        <div class="row">
            <?php foreach ($admins as $admin): ?>
                <div class="col-md-4">
                    <div class="admin-card">
                        <img src="http://localhost/uploads/admins/vogel-2-1024x479.jpg" alt="Admin Picture">
                        <div class="card-body">
                            <div class="admin-name"><?php echo htmlspecialchars($admin['username']); ?></div>
                            <div class="admin-type"><?php echo ucfirst($admin['role']); ?></div>
                            <div class="action-buttons">
                                <a href="edit_admin.php?id=<?php echo $admin['id']; ?>" class="btn btn-edit btn-sm me-2">
                                    <i class="bi bi-pencil"></i> Edit
                                </a>
                                <a href="delete_admin.php?id=<?php echo $admin['id']; ?>" class="btn btn-delete btn-sm delete-admin">
                                    <i class="bi bi-trash"></i> Delete
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Bootstrap Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!-- Confirmation Prompt for Delete -->
    <script>
        document.querySelectorAll('.delete-admin').forEach(button => {
            button.addEventListener('click', function (e) {
                if (!confirm('Are you sure you want to delete this admin?')) {
                    e.preventDefault();
                }
            });
        });
    </script>
</body>
</html>

<?php
require 'includes/footer.php';?>