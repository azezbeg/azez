<?php
require 'db.php';
require 'includes/header.php';



// Fetch categories from the database
$sql = "SELECT * FROM categories";
$stmt = $pdo->query($sql);
$categories = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Categories</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- SweetAlert2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <style>
        body {
            background: #f4f4f9;
        }
        .navbar {
            background: linear-gradient(to right, #2575fc, #6a11cb);
            color: white;
        }
        .navbar-brand {
            font-weight: bold;
            color: #fff !important;
        }
        <style>
    .card {
        border: none;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        text-align: center;
        overflow: hidden;
    }
    .card-header {
        background-color: #f8f9fa;
        padding: 10px;
        font-size: 1.1rem;
        font-weight: bold;
    }
    .card-img-top {
        width: 100%;
        height: 150px;
        object-fit: cover;
    }
    .btn-container {
        margin-top: 10px;
        display: flex;
        justify-content: center;
        gap: 10px;
    }
    .btn-container a {
        font-size: 1rem;
    }



    </style>
</head>
<body>
   

    <!-- Manage Categories -->
    <div class="container mt-4">
        <h3 class="mb-4">Manage Categories</h3>
        <div class="row">
            <?php if (empty($categories)): ?>
                <p class="text-center">No categories found. <a href="add_category.php">Add a new category</a>.</p>
            <?php else: ?>
                <?php foreach ($categories as $category): ?>
                    <div class="col-md-3 mb-4">
    <div class="card">
        <!-- Category Image -->
        <img src="<?php echo htmlspecialchars($category['image']); ?>" alt="Category Image">
        
        <!-- Category Name -->
        <div class="card-body">
            <h5 class="card-title text-center"><?php echo htmlspecialchars($category['name']); ?></h5>
            
            <!-- Buttons -->
            <div class="btn-container">
                <a href="edit_category.php?id=<?php echo $category['id']; ?>" class="btn btn-primary btn-sm">Edit</a>
                <a href="#" class="btn btn-danger btn-sm delete-category" data-id="<?php echo $category['id']; ?>">Delete</a>
            </div>
        </div>
    </div>
</div>

                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Delete confirmation
        document.querySelectorAll('.delete-category').forEach(button => {
            button.addEventListener('click', function (e) {
                e.preventDefault();
                const categoryId = this.dataset.id;

                Swal.fire({
                    title: 'Are you sure?',
                    text: 'Do you want to delete this category? This action cannot be undone!',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Redirect to delete_category.php with category ID
                        window.location.href = `delete_category.php?id=${categoryId}`;
                    }
                });
            });
        });
    </script>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
require 'includes/footer.php';?>