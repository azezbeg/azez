<?php
require 'db.php';
require 'includes/header.php';



require 'db.php';

// Fetch items from the database
$sql = "SELECT i.id, i.uyghur_name, i.english_name, i.arabic_name, i.image, c.name AS category_name 
        FROM items i
        JOIN categories c ON i.category_id = c.id";
$stmt = $pdo->query($sql);
$items = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Items</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- SweetAlert2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css" rel="stylesheet">
    <style>
        body {
            background: #f4f4f9;
        }
        .navbar {
            background: linear-gradient(to right, #2575fc, #6a11cb);
            color: white;
        }
        .navbar-brand {
            font-weight: bold;
            color: #fff !important;
        }
        .card {
            position: relative;
            border: none;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            text-align: center;
            height: 350px;
        }
        .card img {
            width: 100%;
            height: 150px;
            object-fit: cover;
        }
        .card-body {
            display: flex;
            flex-direction: column;
            justify-content: space-between;
            height: 100%;
        }
        .card-body h5 {
            font-size: 1.1rem;
            margin: 10px 0;
        }
        .btn-container {
            margin-top: auto;
            display: flex;
            justify-content: space-between;
        }
        .btn-container a {
            font-size: 1.2rem;
            color: #6c757d;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        .btn-container a:hover {
            color: #2575fc;
        }
    </style>
</head>
<body>
    

    <!-- Manage Items -->
    <div class="container mt-4">
        <h3 class="mb-4">Manage Items</h3>
        <div class="row">
            <?php if (empty($items)): ?>
                <p class="text-center">No items found. <a href="add_item.php">Add a new item</a>.</p>
            <?php else: ?>
                <?php foreach ($items as $item): ?>
                    <div class="col-md-3 mb-4">
                        <div class="card">
                            <!-- Image -->
                           
                            <!-- Card Body -->
                            <div class="card-body">
                            <img src="<?php echo htmlspecialchars($item['image']); ?>" alt="Item Image">
                                <h5><?php echo htmlspecialchars($item['uyghur_name']); ?></h5>
                                <!-- Buttons -->
                                <div class="btn-container">
                                    <a href="edit_item.php?id=<?php echo $item['id']; ?>" title="Edit">
                                        <i class="bi bi-pencil-square"></i> Edit
                                    </a>
                                    <a href="#" class="delete-btn" data-id="<?php echo $item['id']; ?>" title="Delete">
                                        <i class="bi bi-trash"></i> Delete
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>

    <!-- SweetAlert2 JS -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script>
        // Delete confirmation
        document.querySelectorAll('.delete-btn').forEach(button => {
            button.addEventListener('click', function (e) {
                e.preventDefault();
                const itemId = this.dataset.id;

                Swal.fire({
                    title: 'Are you sure?',
                    text: 'This action cannot be undone!',
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        window.location.href = `delete_item.php?id=${itemId}`;
                    }
                });
            });
        });
    </script>

    <!-- Bootstrap Icons -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.js"></script>
</body>
</html>

<?php
require 'includes/footer.php';?>