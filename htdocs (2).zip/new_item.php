<?php
include 'header.php';
// Include database connection

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $englishName = $_POST['english_name'];
    $uyghurName = $_POST['uyghur_name'];
    $arabicName = $_POST['arabic_name'];
    $image = $_FILES['image'];

    // Image upload logic
    $targetDir = "uploads/";
    $targetFile = $targetDir . basename($image['name']);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Check if the file is an image
    if (isset($_POST['submit'])) {
        $check = getimagesize($image['tmp_name']);
        if ($check !== false) {
            $uploadOk = 1;
        } else {
            echo "File is not an image.";
            $uploadOk = 0;
        }
    }

    // Check if file already exists
    if (file_exists($targetFile)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
    }

    // Check file size
    if ($image['size'] > 5000000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    // Allow only certain file formats
    if (
        $imageFileType != "jpg" && $imageFileType != "png" &&
        $imageFileType != "jpeg" && $imageFileType != "gif"
    ) {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    // Attempt to upload file
    if ($uploadOk == 1) {
        if (move_uploaded_file($image['tmp_name'], $targetFile)) {
            // Save item in the database
            $stmt = $pdo->prepare("INSERT INTO items (english_name, uyghur_name, arabic_name, image) VALUES (?, ?, ?, ?)");
            $stmt->execute([$englishName, $uyghurName, $arabicName, $targetFile]);

            echo "The file " . htmlspecialchars(basename($image['name'])) . " has been uploaded.";
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>New Item</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<div class="container mt-5">
    <h2 class="text-center">Add New Item</h2>
    <form action="new_item.php" method="POST" enctype="multipart/form-data">
        <div class="mb-3">
            <label for="english_name" class="form-label">English Name</label>
            <input type="text" class="form-control" id="english_name" name="english_name" required>
        </div>
        <div class="mb-3">
            <label for="uyghur_name" class="form-label">Uyghur Name</label>
            <input type="text" class="form-control" id="uyghur_name" name="uyghur_name" required>
        </div>
        <div class="mb-3">
            <label for="arabic_name" class="form-label">Arabic Name</label>
            <input type="text" class="form-control" id="arabic_name" name="arabic_name" required>
        </div>
        <div class="mb-3">
            <label for="image" class="form-label">Image</label>
            <input type="file" class="form-control" id="image" name="image" accept="image/*" required>
        </div>
        <button type="submit" class="btn btn-primary">Add Item</button>
    </form>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
