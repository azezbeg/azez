<?php
require 'db.php'; // Database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];

    // ئىشلەتكۈچى نامى 3 ھەرىپتىن تۆۋەن بولماسلىقى كېرەك
    if (strlen($username) < 3) {
        $error = "Username must be at least 3 characters!";
    }
    // ئېلخەت نۇسخىسىنى تەكشۈرۈش
    elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email address!";
    }
   
    // پارولنىڭ ئوخشىشىنى تەكشۈرۈش
    elseif ($password !== $confirmPassword) {
        $error = "Passwords do not match!";
    } else {
        // پارولنى `password_hash` ئارقىلىق شېفىرلاش
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        // ئىشلەتكۈچى نامى ياكى ئېلخەت مەۋجۇتلىقىنى تەكشۈرۈش
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $error = "Username or email already exists!";
        } else {
            // يىڭى ئىشلەتكۈچىنى قوشۇش (email نامى قوشۇلدى)
            $insertStmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
            $insertStmt->bind_param("sss", $username, $email, $hashedPassword);

            if ($insertStmt->execute()) {
                $success = "User registered successfully! You can now <a href='login.php'>log in</a>.";
            } else {
                $error = "An error occurred while registering. Please try again.";
            }
            $insertStmt->close();
        }
        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Register</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
  <style>
    .input-group-text.pointer {
      cursor: pointer;
    }
  </style>
</head>
<body>
  <div class="container d-flex justify-content-center align-items-center" style="height: 100vh;">
    <div class="card p-4 shadow-lg" style="max-width: 400px; width: 100%;">
      <h3 class="text-center mb-4">Register</h3>
      <?php if (isset($success)): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
      <?php elseif (isset($error)): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
      <?php endif; ?>
      <form method="POST">
        <!-- Username Field -->
        <div class="mb-3">
          <label for="username" class="form-label">Username</label>
          <div class="input-group">
            <span class="input-group-text"><i class="fa fa-user"></i></span>
            <input type="text" id="username" name="username" class="form-control" required>
          </div>
        </div>
        <!-- Email Field -->
        <div class="mb-3">
          <label for="email" class="form-label">Email</label>
          <div class="input-group">
            <span class="input-group-text"><i class="fa fa-envelope"></i></span>
            <input type="email" id="email" name="email" class="form-control" required>
          </div>
        </div>
        <!-- Password Field -->
        <div class="mb-3">
          <label for="password" class="form-label">Password</label>
          <div class="input-group">
            <span class="input-group-text"><i class="fa fa-lock"></i></span>
            <input type="password" id="password" name="password" class="form-control" required>
            <span class="input-group-text pointer toggle-password" data-target="password">
              <i class="fa fa-eye"></i>
            </span>
          </div>
          <small class="text-muted">At least 8 characters, including 1 number.</small>
        </div>
        <!-- Confirm Password Field -->
        <div class="mb-3">
          <label for="confirm_password" class="form-label">Confirm Password</label>
          <div class="input-group">
            <span class="input-group-text"><i class="fa fa-lock"></i></span>
            <input type="password" id="confirm_password" name="confirm_password" class="form-control" required>
            <span class="input-group-text pointer toggle-password" data-target="confirm_password">
              <i class="fa fa-eye"></i>
            </span>
          </div>
        </div>
        <button type="submit" class="btn btn-primary w-100">Register</button>
      </form>
      <div class="text-center mt-3">
        <a href="login.php">Already have an account? Log in</a>
      </div>
    </div>
  </div>

  <!-- JavaScript to toggle password visibility -->
  <script>
    document.querySelectorAll('.toggle-password').forEach(function(toggle) {
      toggle.addEventListener('click', function() {
        var targetInput = document.getElementById(this.getAttribute('data-target'));
        if (targetInput.getAttribute('type') === 'password') {
          targetInput.setAttribute('type', 'text');
          this.innerHTML = '<i class="fa fa-eye-slash"></i>';
        } else {
          targetInput.setAttribute('type', 'password');
          this.innerHTML = '<i class="fa fa-eye"></i>';
        }
      });
    });
  </script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
