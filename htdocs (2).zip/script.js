document.addEventListener("DOMContentLoaded", () => {
    const toggleButton = document.getElementById("menu-toggle");
    const sidebarWrapper = document.getElementById("sidebar-wrapper");

    toggleButton.addEventListener("click", () => {
        sidebarWrapper.classList.toggle("collapsed");
    });
});
