<?php
require 'db.php';
require 'includes/header.php';



// Fetch current settings
$stmt = $pdo->query("SELECT * FROM settings LIMIT 1");
$current_settings = $stmt->fetch(PDO::FETCH_ASSOC);

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $website_name = htmlspecialchars($_POST['website_name']);
    $welcome_name = htmlspecialchars($_POST['welcome_name']);
    $logo_path = $current_settings['logo'] ?? '';

    // Handle logo upload
    if (!empty($_FILES['logo']['name'])) {
        $upload_dir = 'uploads/';
        $logo_path = $upload_dir . basename($_FILES['logo']['name']);
        move_uploaded_file($_FILES['logo']['tmp_name'], $logo_path);
    }

    if ($current_settings) {
        // Update settings
        $stmt = $pdo->prepare("UPDATE settings SET website_name = ?, welcome_name = ?, logo = ? WHERE id = ?");
        $stmt->execute([$website_name, $welcome_name, $logo_path, $current_settings['id']]);
    } else {
        // Insert new settings if they don't exist
        $stmt = $pdo->prepare("INSERT INTO settings (website_name, welcome_name, logo) VALUES (?, ?, ?)");
        $stmt->execute([$website_name, $welcome_name, $logo_path]);
    }

    $success = "Settings updated successfully.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        .settings-container {
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            margin: 50px auto;
        }
        .settings-title {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 20px;
            text-align: center;
        }
        .logo-preview {
            display: block;
            margin: 10px auto;
            max-width: 150px;
            max-height: 150px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
    </style>
</head>
<body>

    
    <div class="container mt-4">
        <div class="settings-container">
            <h1 class="settings-title">Settings</h1>

            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>

            <form method="POST" enctype="multipart/form-data">
                <div class="mb-3">
                    <label for="website_name" class="form-label">Website Name</label>
                    <input type="text" class="form-control" id="website_name" name="website_name" value="<?php echo htmlspecialchars($current_settings['website_name'] ?? ''); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="welcome_name" class="form-label">Login Page Welcome Name</label>
                    <input type="text" class="form-control" id="welcome_name" name="welcome_name" value="<?php echo htmlspecialchars($current_settings['welcome_name'] ?? ''); ?>" required>
                </div>
                <div class="mb-3">
                    <label for="logo" class="form-label">Logo</label>
                    <?php if (!empty($current_settings['logo'])): ?>
                        <img src="<?php echo htmlspecialchars($current_settings['logo']); ?>" alt="Logo" class="logo-preview">
                    <?php endif; ?>
                    <input type="file" class="form-control" id="logo" name="logo" accept="image/*">
                </div>
                <button type="submit" class="btn btn-primary w-100">Save Changes</button>
            </form>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
require 'includes/footer.php';?>