<?php
// مەشغۇلاتقا ئۇلاش
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "admin_panel";

// سېرۋېرغا ئۇلاش
$conn = new mysqli($servername, $username, $password, $dbname);

// ئۇلاشقا تەكشۈرۈش
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// POST ئارقىلىق مەلۇماتنى ئالغاندىن كىيىن تىزىملاش
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // بوش مەلۇماتلارغا تەكشۈرۈش
    if (empty($username) || empty($email) || empty($password)) {
        echo json_encode(['status' => 'error', 'message' => 'ئىشلەتكۈچى ئىسمى، ئېلخەت ۋە پارول بوشلۇقى تامامەن تولدۇرۇلۇشى كېرەك.']);
        exit();
    }

    // پارولنى خەفىيلاشتۇرۇش
    $password = password_hash($password, PASSWORD_DEFAULT);

    // ئېلخەتنى تەكشۈرۈش: بەرگەن ئېلخەت بويىچە مەۋجۇت بولسا
    $emailCheckQuery = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($emailCheckQuery);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // ئېلخەت ئاللىقاچان مەۋجۇت
        echo json_encode(['status' => 'error', 'message' => 'بۇ ئېلخەت ئاللىقاچان تىزىملىتىلغان.']);
        exit();
    }

    // ئىشلەتكۈچىنى تەكشۈرۈش: تىزىملىتىلغان ئىشلەتكۈچى نامى بويىچە
    $usernameCheckQuery = "SELECT * FROM users WHERE username = ?";
    $stmt = $conn->prepare($usernameCheckQuery);
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // ئىشلەتكۈچى نامى ئاللىقاچان مەۋجۇت
        echo json_encode(['status' => 'error', 'message' => 'بۇ ئىشلەتكۈچى نامى ئاللىقاچان قوللىنىلىۋاتىدۇ.']);
        exit();
    }

    // ئىشلىتىش ئۈچۈن تېييارلاش ۋە بەلگىلەش
    $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $username, $email, $password);

    // مەشغۇلاتنى ئىجرا قىلىش
    if ($stmt->execute()) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'تىزىملاش مەغلۇب بولدى. قايتا سىناپ بېقىڭ.']);
    }

    $stmt->close();
}

$conn->close();
?>
