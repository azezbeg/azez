<?php
require 'db.php';
require 'includes/header.php';



// Check if the user is logged in
if (!isset($_SESSION['logged_in'])) {
    header('Location: login.php');
    exit;
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = htmlspecialchars($_POST['user_id']);
    $api_key = htmlspecialchars($_POST['api_key']);

    // Validate the API key and user ID
    $stmt = $pdo->prepare("SELECT * FROM admin_api_keys WHERE user_id = ? AND api_key = ?");
    $stmt->execute([$user_id, $api_key]);
    $api_record = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($api_record) {
        // API key is valid - redirect to the dashboard
        $_SESSION['verified'] = true; // Optional: set a session variable to mark verification
        header('Location: dashboard.php');
        exit;
    } else {
        // API key is invalid - redirect to the purchase page
        header('Location: purchase.php');
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verify API Key</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .verification-container {
            max-width: 500px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .verification-title {
            font-size: 1.5rem;
            font-weight: bold;
            margin-bottom: 20px;
            text-align: center;
        }
        .btn-custom {
            background-color: #007bff;
            color: #fff;
        }
        .btn-custom:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="verification-container">
            <h1 class="verification-title">Verify API Key</h1>

            <form method="POST">
                <div class="mb-3">
                    <label for="user_id" class="form-label">User ID</label>
                    <input type="text" class="form-control" id="user_id" name="user_id" required>
                </div>
                <div class="mb-3">
                    <label for="api_key" class="form-label">API Key</label>
                    <input type="text" class="form-control" id="api_key" name="api_key" required>
                </div>
                <button type="submit" class="btn btn-custom w-100">Verify</button>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
require 'includes/footer.php';?>